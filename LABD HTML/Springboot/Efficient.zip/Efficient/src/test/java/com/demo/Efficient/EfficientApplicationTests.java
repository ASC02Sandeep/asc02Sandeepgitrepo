package com.demo.Efficient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EfficientApplicationTests {

	@Test
	void contextLoads() {
	}

}
