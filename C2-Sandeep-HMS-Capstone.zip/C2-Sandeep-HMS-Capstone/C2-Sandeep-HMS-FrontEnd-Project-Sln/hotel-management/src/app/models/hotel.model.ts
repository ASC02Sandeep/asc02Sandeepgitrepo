export class Hotel {
    id?: string; // Auto-generated
    name?: string;
    location?: string;
    roomsAvailable?: number;
    rating?: number;
  }
  