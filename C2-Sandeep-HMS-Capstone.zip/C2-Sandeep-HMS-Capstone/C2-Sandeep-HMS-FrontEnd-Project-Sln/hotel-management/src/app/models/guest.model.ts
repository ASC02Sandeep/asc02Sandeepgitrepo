export class Guest {
    id?: string; // Auto-generated
    name?: string;
    email?: string;
    phone?: string;
    address?: string;
    roomNumber?: string;
  }
  