export class Review {
    hotelName?: string;
    rating?: number;
    comments?: string;
  }
  