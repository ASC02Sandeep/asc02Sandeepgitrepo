export class Booking {
  id?: string; // Auto-generated
  guestName?: string;
  hotel?: string; // Reference to hotel
  roomNumber?: string;
  checkInDate?: string;
  checkOutDate?: string;
  status?: string;
}

  