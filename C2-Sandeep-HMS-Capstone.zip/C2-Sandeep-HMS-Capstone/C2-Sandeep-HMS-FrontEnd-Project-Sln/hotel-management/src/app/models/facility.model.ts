export class Facility {
    hotelName?: string;
    facilityType?: string;
    availability?: string;
    description?: string;
  }
  