package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HmsBackendApplication {

	public static void main(String[] args) {

		System.out.println("Just another Java App, not any more!");
		SpringApplication.run(HmsBackendApplication.class, args);
	}

}
